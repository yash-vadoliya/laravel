<footer style="background-color: #333; color: #fff; text-align: center; padding: 10px; margin-top: 70px;">
    <p>&copy; 2024 Dhaval Sojitra. All Rights Reserved.</p>
</footer>
