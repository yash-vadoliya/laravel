@extends('layout')

@section('content')
<h1>

    Welcome to home....
</h1>
@endsection
