<footer class="mt-5">
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        © 2021 Copyright:
        <a class="text-reset fw-bold" href="https://mdbootstrap.com/">MDBootstrap.com</a>
      </div>

</footer>
<?php /**PATH D:\MCA\Sem 2\Github\Laravel\exam2.0\resources\views/template/footer.blade.php ENDPATH**/ ?>