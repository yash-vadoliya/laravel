<?php $__env->startSection('content'); ?>

<h2>Title :</h2>
<p><?php echo e($mypost->title); ?></p>
<hr>
<h2>Subtitle :</h2>
<p><?php echo e($mypost->subtitle); ?></p>
<hr>
<h2>Content :</h2>
<p><?php echo e($mypost->content); ?></p>
<hr>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\exam2.0\resources\views/user/show.blade.php ENDPATH**/ ?>