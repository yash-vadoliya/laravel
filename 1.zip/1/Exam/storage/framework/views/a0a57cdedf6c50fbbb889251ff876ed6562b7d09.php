<?php $__env->startSection('content'); ?>
    <h1 align="center">Welcome to Mypost</h1>
    <div class="container">
        <table class="table thead-dark table-striped table-bordered table-hover table-sm">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Title</th>
                    <th scope="col">Subtitle</th>
                    <th scope="col">Content</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                    <th scope="col">Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mypost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($d->getUser->id); ?></th>
                        <td><?php echo e($d->title); ?></td>
                        <td><?php echo e($d->subtitle); ?></td>
                        <td><?php echo $d->content; ?></td>
                        <td>
                            <a class="btn btn-warning" href="<?php echo e(route('mypost.edit',$d->slug)); ?>">Edit</a>
                        </td>
                        <td>
                            <form action="<?php echo e(route('mypost.destroy',$d->slug)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                        <td>
                            <a class="btn btn-primary" href="<?php echo e(route('mypost.show',$d->slug)); ?>">Show</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <div style="display: flex; align-items: center; justify-content: center">

            <?php echo e($mypost->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\exam2.0\resources\views/user/index.blade.php ENDPATH**/ ?>