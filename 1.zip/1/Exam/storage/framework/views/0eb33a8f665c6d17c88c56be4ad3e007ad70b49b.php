<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('mypost.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label>Title</label>
      <input type="text" name="title" class="form-control" placeholder="Enter title">
    </div>
    <div class="form-group">
      <label>Subtitle</label>
      <input type="text" name="subtitle" class="form-control" id="exampleInputPassword1" placeholder="Enter Subtitle">
    </div>
    <div class="form-group">
      <label>Content</label>
      <textarea class="form-control" id="editor" name="content" rows="3"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MCA\Sem 2\Github\Laravel\exam2.0\resources\views/user/create.blade.php ENDPATH**/ ?>