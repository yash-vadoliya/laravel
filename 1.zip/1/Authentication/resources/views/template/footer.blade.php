<style>
    footer{
        background-color: #333;
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 10px;
        margin-top: 50px;
    }
</style>
<footer>
    <p>&copy; 2024 Mypost. All Rights Reserved.</p>
</footer>
