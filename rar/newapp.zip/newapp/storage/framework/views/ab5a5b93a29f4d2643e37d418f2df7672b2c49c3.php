<?php $__env->startSection('content'); ?>

<form class="container" method="post" action="<?php echo e(route('store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInput" class="form-label">Title</label>
      <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Title">
    </div>
    <div class="mb-3">
      <label for="exampleInput" class="form-label">Subtitle</label>
      <input type="text" name="subtitle" class="form-control" id="exampleInputPassword1" placeholder="Your Sub Title">
    </div>
    <div class="mb-3">
        <label for="exampleInput" class="form-label" >Body</label>
        <textarea name="body" class="form-control" placeholder="Your Body Area" id="floatingTextarea"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Yash\Laravel\newapp\resources\views/template/create.blade.php ENDPATH**/ ?>