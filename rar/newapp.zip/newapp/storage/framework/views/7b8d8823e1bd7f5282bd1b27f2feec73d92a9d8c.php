<?php $__env->startSection('contact'); ?>

<div class="container-fluide">
    <h3>Contact Details</h3>
    <p>Name : Yash Vadoliya</p>
    <p>Conatct No : 8758787706</p>
    <address>1,Sahayog chamber,Talav darvaja,Junagadh 362001</address>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Yash\Laravel\newapp\resources\views/contact.blade.php ENDPATH**/ ?>