<?php $__env->startSection('content'); ?>
<h3>About Page</h3>
<p>
    <span>
        <span>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorum, modi veniam sed doloremque dignissimos hic tempore mollitia. Eveniet beatae a, similique sequi sint rerum rem natus deserunt explicabo dolore qui.</span>
        <span>Reprehenderit sunt ad harum cum officiis, dignissimos, dolore ratione sint vitae, consectetur pariatur. Deserunt ut harum itaque pariatur animi debitis maiores odio ipsam perspiciatis totam aut adipisci suscipit, quos enim!</span>
        <span>Obcaecati explicabo voluptatum accusamus laboriosam. Reprehenderit sequi quia atque nulla explicabo molestias deleniti exercitationem sit, adipisci, modi omnis sunt ad accusamus culpa. Eaque, cum porro rem odio nesciunt similique nostrum!</span>
        <span>Minima velit distinctio possimus excepturi, consequuntur officiis voluptates fugit modi amet ipsa magni doloribus dolorem accusamus deserunt eligendi facere a aliquid, dignissimos saepe tenetur necessitatibus iusto, nisi pariatur? Amet, nihil.</span>
        <span>Dignissimos nesciunt sapiente et quas eveniet, incidunt est, eum ea iste aliquam alias officia natus? Animi, eos dolor expedita incidunt nisi voluptatem, consectetur esse repellat alias vel saepe? Nobis, atque!</span>
    </span>
</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Yash\Laravel\newapp\resources\views/user/about.blade.php ENDPATH**/ ?>