
<header class="p-1 text-center">
    <h1>Yash Vadoliya</h1>
</header>
<div>
    <nav class="navbar bg-dark border-bottom border-body" data-bs-theme="dark">
        <nav class="navbar navbar-expand-lg navbar-light bg-dark text-whi">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active text-white" aria-current="page" href="/home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="/contact">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="/about">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="/form">Form</a>
                </li>
            </div>
            </div>
        </nav>
    </nav>
</div>
<?php /**PATH F:\Yash\Laravel\newapp\resources\views/template/header.blade.php ENDPATH**/ ?>