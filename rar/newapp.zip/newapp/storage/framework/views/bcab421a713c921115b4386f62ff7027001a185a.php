<p class="p-2 m-2 bg-dark text-white">Yash Vadoliya</p>
<?php /**PATH F:\Yash\Laravel\newapp\resources\views/template/footer.blade.php ENDPATH**/ ?>