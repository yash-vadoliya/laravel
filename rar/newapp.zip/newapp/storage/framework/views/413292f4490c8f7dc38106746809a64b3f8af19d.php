


<div class="continer-fluid">
    <div class="p-1 m-1 text-justify">
        <p>
            <span>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate vel dolorum sunt, possimus sit tempora quod adipisci aliquam modi delectus, iste alias repellat consequatur accusamus animi nesciunt debitis reiciendis libero.</span>
            <span>Molestias aliquid debitis officiis reiciendis et cupiditate, optio numquam tempora vitae nihil, aspernatur reprehenderit ullam labore commodi provident quasi magnam repellat earum quos, ducimus consectetur placeat. Eligendi nostrum sequi soluta.</span>
            <span>Accusamus perspiciatis consequatur quod veniam placeat iste corporis doloremque velit. Eum, voluptatibus. Omnis, sequi voluptates? Iste corporis dicta repellat vitae magnam eligendi, ex dolorem aut assumenda possimus, blanditiis culpa minima?</span>
            <span>Aperiam facilis quidem autem amet. Ratione vel eaque, nulla voluptate assumenda voluptatibus laborum. Adipisci debitis consequuntur illo eos repellat iste provident ratione, sapiente praesentium, soluta magnam, deserunt suscipit ipsa libero!</span>
            <span>Aliquam a quos corporis nostrum natus. Quibusdam placeat enim commodi consectetur tenetur alias, dignissimos harum deserunt omnis mollitia assumenda qui voluptatibus labore eos quisquam dicta, dolores tempore? Placeat, minima a.</span>
            <span>Nostrum cumque, fuga tempore eligendi voluptatem aliquam cupiditate deserunt, maiores quis, aperiam voluptate nam quod accusantium ea rerum delectus ratione! Corporis eum fuga eius ex nesciunt blanditiis alias distinctio excepturi.</span>
            <span>Ducimus, velit minima! Repudiandae exercitationem blanditiis omnis nemo eum voluptatibus deleniti quos? Numquam voluptas reiciendis temporibus doloremque maiores vel harum, similique ullam deserunt enim, tempora, ratione explicabo aspernatur perspiciatis accusantium!</span>
            <span>Iure consectetur necessitatibus quia ipsam delectus inventore explicabo obcaecati perspiciatis quas. Iure blanditiis voluptates harum! Aliquam sit officia ducimus soluta nostrum dolorum corrupti possimus. Ducimus doloremque enim tempore illo repudiandae!</span>
            <span>Recusandae minus quasi aut eligendi dolorem fuga non, vel nesciunt. Voluptatem voluptas vel obcaecati architecto deserunt repudiandae, pariatur suscipit asperiores reprehenderit quidem blanditiis recusandae quasi exercitationem laborum neque quo laboriosam!</span>
            <span>Sed a beatae amet laboriosam ipsa. Harum a eos magni sapiente placeat voluptatum eum deserunt veritatis, temporibus cupiditate ipsum, iste quam repellat doloribus corporis amet maxime minima vero ipsam fugiat?</span>
        </p>
    </div>
</div>
<div class="continer-fluid">
    <div class="p-1 m-1 text-justify">
        <p>
            <span>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptate vel dolorum sunt, possimus sit tempora quod adipisci aliquam modi delectus, iste alias repellat consequatur accusamus animi nesciunt debitis reiciendis libero.</span>
            <span>Molestias aliquid debitis officiis reiciendis et cupiditate, optio numquam tempora vitae nihil, aspernatur reprehenderit ullam labore commodi provident quasi magnam repellat earum quos, ducimus consectetur placeat. Eligendi nostrum sequi soluta.</span>
            <span>Accusamus perspiciatis consequatur quod veniam placeat iste corporis doloremque velit. Eum, voluptatibus. Omnis, sequi voluptates? Iste corporis dicta repellat vitae magnam eligendi, ex dolorem aut assumenda possimus, blanditiis culpa minima?</span>
            <span>Aperiam facilis quidem autem amet. Ratione vel eaque, nulla voluptate assumenda voluptatibus laborum. Adipisci debitis consequuntur illo eos repellat iste provident ratione, sapiente praesentium, soluta magnam, deserunt suscipit ipsa libero!</span>
            <span>Aliquam a quos corporis nostrum natus. Quibusdam placeat enim commodi consectetur tenetur alias, dignissimos harum deserunt omnis mollitia assumenda qui voluptatibus labore eos quisquam dicta, dolores tempore? Placeat, minima a.</span>
            <span>Nostrum cumque, fuga tempore eligendi voluptatem aliquam cupiditate deserunt, maiores quis, aperiam voluptate nam quod accusantium ea rerum delectus ratione! Corporis eum fuga eius ex nesciunt blanditiis alias distinctio excepturi.</span>
            <span>Ducimus, velit minima! Repudiandae exercitationem blanditiis omnis nemo eum voluptatibus deleniti quos? Numquam voluptas reiciendis temporibus doloremque maiores vel harum, similique ullam deserunt enim, tempora, ratione explicabo aspernatur perspiciatis accusantium!</span>
            <span>Iure consectetur necessitatibus quia ipsam delectus inventore explicabo obcaecati perspiciatis quas. Iure blanditiis voluptates harum! Aliquam sit officia ducimus soluta nostrum dolorum corrupti possimus. Ducimus doloremque enim tempore illo repudiandae!</span>
            <span>Recusandae minus quasi aut eligendi dolorem fuga non, vel nesciunt. Voluptatem voluptas vel obcaecati architecto deserunt repudiandae, pariatur suscipit asperiores reprehenderit quidem blanditiis recusandae quasi exercitationem laborum neque quo laboriosam!</span>
            <span>Sed a beatae amet laboriosam ipsa. Harum a eos magni sapiente placeat voluptatum eum deserunt veritatis, temporibus cupiditate ipsum, iste quam repellat doloribus corporis amet maxime minima vero ipsam fugiat?</span>
        </p>
    </div>
</div>


<?php /**PATH F:\Yash\Laravel\newapp\resources\views/details.blade.php ENDPATH**/ ?>