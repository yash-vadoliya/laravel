<?php

namespace App\Http\Controllers;

use App\Models\Myblogs;
use Illuminate\Http\Request;

class MyController extends Controller
{
    public function index(){
        return view('template.index');
    }

    public function home(){
        return view('user.home');
    }

    public function store(Request $request){
        $myblog = new Myblogs();
        $myblog->title = $request->title;
        $myblog->subtitle = $request->subtitle;
        $myblog->body = $request->body;
        $myblog->save();
    }

    public function contact(){
        return view('user.contact');
    }

    public function about(){
        return view('user.about');
    }

    public function create(){
        return view('template.create');
    }
}
